package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High-contrast primary colors (Kodyar Slate Blue & Deep Ruby Red)
val KodyarPrimary = Color(0xFF0F172A)     // Dark slate blue (Primary brand)
val KodyarSecondary = Color(0xFF1E293B)   // Dark Slate (for containers and readable headings)
val KodyarTertiary = Color(0xFF334155)    // Slate dark gray (for body text and secondary icons)

// Vibrant Accent Color
val KodyarAccent = Color(0xFFDC2626)      // Intense High-Contrast Red (Active buttons & badges)
val KodyarSuccess = Color(0xFF15803D)     // Deep emerald green for success elements
val KodyarWarning = Color(0xFFB45309)     // Rich amber for warning/alert items
val KodyarPremium = Color(0xFF6D28D9)     // Vivid violet for premium features

// Backgrounds
val KodyarBackground = Color(0xFFF1F5F9)  // Clean slate background (not pure stark white, easy on the eyes)
val KodyarSurface = Color(0xFFFFFFFF)     // Card surface background
val KodyarSurfaceVariant = Color(0xFFE2E8F0) // Distinct divider/border colors

// Text Color Accents (Ensuring maximum readability)
val TextDarkPrimary = Color(0xFF0F172A)   // Ultra dark slate (almost black) for primary text
val TextDarkSecondary = Color(0xFF334155) // Dark slate for subheadings/labels (extremely high contrast)
val TextDarkHint = Color(0xFF64748B)      // Medium slate for place holders/borders (passes accessibility check)
val TextLightPrimary = Color(0xFFFFFFFF)  // Pure white for dark components
val TextLightSecondary = Color(0xFFE2E8F0)// Very light slate for subtitle elements inside dark headers
