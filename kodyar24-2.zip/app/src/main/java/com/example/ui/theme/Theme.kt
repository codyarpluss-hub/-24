package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = KodyarPrimary,
    secondary = KodyarSecondary,
    tertiary = KodyarTertiary,
    background = KodyarBackground,
    surface = KodyarSurface,
    onPrimary = TextLightPrimary,
    onSecondary = TextLightPrimary,
    onTertiary = TextLightPrimary,
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    surfaceVariant = KodyarSurfaceVariant,
    onSurfaceVariant = TextDarkSecondary,
    error = KodyarAccent,
    onError = TextLightPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
