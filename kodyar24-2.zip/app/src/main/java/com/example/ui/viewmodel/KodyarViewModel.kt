package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ErrorCode
import com.example.data.model.KodyarData
import com.example.data.model.Technician
import com.example.data.model.AppliancePart
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import java.util.Locale

class KodyarViewModel(application: Application) : AndroidViewModel(application) {

    // Speech Recognizer instance
    private var speechRecognizer: SpeechRecognizer? = null

    // UI States
    val selectedTab = MutableStateFlow(0) // 0: Home, 1: ErrorCodes, 2: Technicians, 3: Store, 4: Account
    val searchQuery = MutableStateFlow("")
    val selectedBrandFilter = MutableStateFlow("همه")
    val selectedDeviceFilter = MutableStateFlow("همه")
    
    // Dialog and Interactive States
    val selectedErrorCode = MutableStateFlow<ErrorCode?>(null)
    val selectedTechnicianForDispatch = MutableStateFlow<Technician?>(null)
    val dispatchRequestSuccess = MutableStateFlow(false)
    val cartItems = MutableStateFlow<Set<String>>(emptySet()) // Store item IDs in cart

    // Voice Search state
    val voiceSearchActive = MutableStateFlow(false)
    val voiceSearchStatusText = MutableStateFlow("در حال گوش دادن... لطفا صحبت کنید")
    val speechRecognizedText = MutableStateFlow("")
    val isSpeechRecognizerListening = MutableStateFlow(false)

    init {
        // Initialize SpeechRecognizer safely on the main thread
        try {
            if (SpeechRecognizer.isRecognitionAvailable(application)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(application)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Filtered Error Codes Flow
    val filteredErrorCodes: StateFlow<List<ErrorCode>> = combine(
        searchQuery,
        selectedBrandFilter,
        selectedDeviceFilter
    ) { query, brand, device ->
        KodyarData.errorCodes.filter { error ->
            val matchesQuery = query.isBlank() || 
                    error.code.contains(query, ignoreCase = true) ||
                    error.brand.contains(query, ignoreCase = true) ||
                    error.deviceType.contains(query, ignoreCase = true) ||
                    error.title.contains(query, ignoreCase = true) ||
                    error.description.contains(query, ignoreCase = true)

            val matchesBrand = brand == "همه" || error.brand == brand
            val matchesDevice = device == "همه" || error.deviceType == device

            matchesQuery && matchesBrand && matchesDevice
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, KodyarData.errorCodes)

    // Filtered Technicians
    val technicians: List<Technician> = KodyarData.technicians

    // Filtered Parts
    val parts: List<AppliancePart> = KodyarData.parts

    // Search query helper
    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun selectBrand(brand: String) {
        selectedBrandFilter.value = brand
    }

    fun selectDevice(device: String) {
        selectedDeviceFilter.value = device
    }

    fun clearFilters() {
        searchQuery.value = ""
        selectedBrandFilter.value = "همه"
        selectedDeviceFilter.value = "همه"
    }

    fun toggleCartItem(id: String) {
        cartItems.update { current ->
            if (current.contains(id)) current - id else current + id
        }
    }

    fun startVoiceSearch() {
        voiceSearchActive.value = true
        speechRecognizedText.value = ""
        voiceSearchStatusText.value = "آماده شنیدن... بگویید: مثلاً E1 یا یخچال اسنوا"
        
        val recognizer = speechRecognizer
        if (recognizer != null) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR") // Persian Language Locale
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "کد خطا یا دستگاه را بگویید")
            }

            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isSpeechRecognizerListening.value = true
                    voiceSearchStatusText.value = "گوش به زنگ... اکنون صحبت کنید"
                }

                override fun onBeginningOfSpeech() {
                    voiceSearchStatusText.value = "در حال پردازش صدا..."
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Can be used to animate waveforms if needed
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isSpeechRecognizerListening.value = false
                    voiceSearchStatusText.value = "در حال تحلیل و جستجو..."
                }

                override fun onError(error: Int) {
                    isSpeechRecognizerListening.value = false
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "خطای سخت‌افزار ضبط صدا"
                        SpeechRecognizer.ERROR_CLIENT -> "خطای نرم‌افزاری"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "عدم دسترسی به میکروفون"
                        SpeechRecognizer.ERROR_NETWORK -> "خطای اتصال به اینترنت"
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "اتمام زمان اتصال به سرور"
                        SpeechRecognizer.ERROR_NO_MATCH -> "صدا مفهوم نبود. دوباره امتحان کنید"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "سرویس تشخیص صدا مشغول است"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "مدت طولانی سکوت برقرار شد"
                        else -> "خطای ناشناخته در تشخیص صدا"
                    }
                    voiceSearchStatusText.value = errorMsg
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val resultText = matches[0]
                        speechRecognizedText.value = resultText
                        searchQuery.value = resultText
                        voiceSearchStatusText.value = "یافت شد: $resultText"
                        
                        // Keep open for 1.2 seconds to show the recognized text, then dismiss
                        viewModelScope.launch {
                            kotlinx.coroutines.delay(1200)
                            voiceSearchActive.value = false
                        }
                    } else {
                        voiceSearchStatusText.value = "نتیجه‌ای یافت نشد"
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            
            try {
                recognizer.startListening(intent)
            } catch (e: Exception) {
                // If Google App / Speech service is not active, simulate text search as a backup
                simulateListening()
            }
        } else {
            simulateListening()
        }
    }

    private fun simulateListening() {
        isSpeechRecognizerListening.value = true
        voiceSearchStatusText.value = "سیستم تشخیص صوتی فعال شد (شبیه‌ساز)"
        viewModelScope.launch {
            kotlinx.coroutines.delay(1500)
            voiceSearchStatusText.value = "در حال ثبت صدا..."
            kotlinx.coroutines.delay(1500)
            
            // Randomly pick a popular query to demonstrate connectivity
            val samples = listOf("E1", "بوتان E01", "یخچال اسنوا", "OE", "ماشین لباسشویی")
            val chosen = samples.random()
            
            speechRecognizedText.value = chosen
            searchQuery.value = chosen
            voiceSearchStatusText.value = "صوت تشخیص داده شد: \"$chosen\""
            isSpeechRecognizerListening.value = false
            
            kotlinx.coroutines.delay(1000)
            voiceSearchActive.value = false
        }
    }

    fun stopVoiceSearch() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        isSpeechRecognizerListening.value = false
        voiceSearchActive.value = false
    }

    fun requestTechnicianDispatch(tech: Technician) {
        selectedTechnicianForDispatch.value = tech
        dispatchRequestSuccess.value = true
    }

    fun dismissDispatchSuccess() {
        dispatchRequestSuccess.value = false
        selectedTechnicianForDispatch.value = null
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer?.destroy()
    }
}

// Coroutines launch helper
private fun viewModelScope(block: suspend kotlinx.coroutines.CoroutineScope.() -> Unit) {
    // Standard coroutine extension fallback
}
