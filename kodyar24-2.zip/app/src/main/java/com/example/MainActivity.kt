package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.AppliancePart
import com.example.data.model.ErrorCode
import com.example.data.model.KodyarData
import com.example.data.model.Technician
import com.example.ui.theme.*
import com.example.ui.viewmodel.KodyarViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    CompositionLocalProvider(
                        androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.platform.LayoutDirection.Rtl
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding),
                            color = KodyarBackground
                        ) {
                            KodyarAppScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KodyarAppScreen(viewModel: KodyarViewModel = viewModel()) {
    val selectedTabState by viewModel.selectedTab.collectAsState()
    val voiceSearchActive by viewModel.voiceSearchActive.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar & Banner Area (Always visible on top)
            KodyarHeaderBanner(viewModel)

            // Dynamic Main Screen Area (Tab-dependent)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTabState) {
                    0 -> HomeTabScreen(viewModel)
                    1 -> ErrorCodesTabScreen(viewModel)
                    2 -> TechniciansTabScreen(viewModel)
                    3 -> StoreTabScreen(viewModel)
                    4 -> AccountTabScreen(viewModel)
                }
            }

            // High-Contrast Navigation Bar (Respects Safe Area Bottom Padding)
            KodyarBottomNavigationBar(
                selectedTab = selectedTabState,
                onTabSelected = { tabIndex ->
                    viewModel.selectedTab.value = tabIndex
                }
            )
        }

        // Animated Speech Recognition Overlays (Modal overlays)
        AnimatedVisibility(
            visible = voiceSearchActive,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            VoiceSearchDialog(viewModel)
        }

        // Error Code Detail Overlay (Dialog)
        val selectedErr by viewModel.selectedErrorCode.collectAsState()
        if (selectedErr != null) {
            ErrorCodeDetailDialog(
                errorCode = selectedErr!!,
                onDismiss = { viewModel.selectedErrorCode.value = null }
            )
        }

        // Technician Dispatch Success Modal
        val dispatchSuccess by viewModel.dispatchRequestSuccess.collectAsState()
        val dispatchedTech by viewModel.selectedTechnicianForDispatch.collectAsState()
        if (dispatchSuccess && dispatchedTech != null) {
            DispatchSuccessDialog(
                technician = dispatchedTech!!,
                onDismiss = { viewModel.dismissDispatchSuccess() }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KodyarHeaderBanner(viewModel: KodyarViewModel) {
    val context = LocalContext.current
    var searchQueryText by viewModel.searchQuery.collectAsState()

    // Permission launcher for Recording Audio
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                viewModel.startVoiceSearch()
            } else {
                // If denied, fallback is handled inside viewModel's startVoiceSearch() safely
                viewModel.startVoiceSearch()
            }
        }
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(KodyarPrimary, KodyarSecondary)
                )
            )
            .padding(horizontal = 16.dp, vertical = 20.dp)
    ) {
        // App Identity Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Logo & Title (App named changed to کدیار۲۴ as requested)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(KodyarAccent)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "کدیار۲۴ لوگو",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "کدیار۲۴",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp
                        )
                    )
                    Text(
                        text = "مرجع تخصصی عیب‌یابی لوازم خانگی",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.White.copy(alpha = 0.85f),
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }

            // Navigation Shortcuts (Cart Badge count & profile quick links)
            Row(verticalAlignment = Alignment.CenterVertically) {
                val cartCount by viewModel.cartItems.collectAsState()
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .clickable { viewModel.selectedTab.value = 3 },
                    contentAlignment = Alignment.Center
                ) {
                    BadgedBox(
                        badge = {
                            if (cartCount.isNotEmpty()) {
                                Badge(containerColor = KodyarAccent) {
                                    Text(
                                        text = cartCount.size.toString(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "سبد خرید",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Single-Line Slogan ("کد خطای دستگاه را سریع پیدا کنید" in a single line as requested)
        Text(
            text = "کد خطای دستگاه را سریع پیدا کنید",
            style = MaterialTheme.typography.titleMedium.copy(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                textAlign = TextAlign.Center
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        )

        // Search Section Card (Perfect Contrast, High visibility TextFields & voice search integration)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Color.White, RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Voice Search button (Connected directly to Persian SpeechRecognizer)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEF2F2))
                        .clickable {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasPermission) {
                                viewModel.startVoiceSearch()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "جستجوی صوتی",
                        tint = KodyarAccent,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // High Contrast Text Field (Solves typing legibility issues completely!)
                TextField(
                    value = searchQueryText,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = {
                        Text(
                            text = "مثلا: E1 یا یخچال اسنوا...",
                            color = TextDarkHint,
                            fontWeight = FontWeight.Medium
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("search_text_input"),
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = TextDarkPrimary,          // Solid high-contrast text color when focused
                        unfocusedTextColor = TextDarkPrimary,        // Solid high-contrast text color when unfocused
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = KodyarAccent,                   // Vibrant distinct cursor
                        focusedPlaceholderColor = TextDarkHint,
                        unfocusedPlaceholderColor = TextDarkHint
                    ),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "آیکون جستجو",
                            tint = KodyarTertiary
                        )
                    }
                )

                // High contrast clear button if search query is active
                if (searchQueryText.isNotBlank()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "پاک کردن",
                            tint = KodyarTertiary
                        )
                    }
                }

                // Search action button
                Button(
                    onClick = { viewModel.selectedTab.value = 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = KodyarAccent),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(42.dp)
                        .testTag("submit_search_button")
                ) {
                    Text(
                        text = "جستجو",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun KodyarBottomNavigationBar(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val items = listOf(
            Triple("خانه", Icons.Default.Home, Icons.Outlined.Home),
            Triple("کدهای خطا", Icons.Default.Warning, Icons.Outlined.Warning),
            Triple("تکنسین‌ها", Icons.Default.Face, Icons.Outlined.Face),
            Triple("فروشگاه قطعات", Icons.Default.ShoppingCart, Icons.Outlined.ShoppingCart),
            Triple("حساب من", Icons.Default.Person, Icons.Outlined.Person)
        )

        items.forEachIndexed { index, (label, selectedIcon, unselectedIcon) ->
            NavigationBarItem(
                selected = selectedTab == index,
                onClick = { onTabSelected(index) },
                icon = {
                    Icon(
                        imageVector = if (selectedTab == index) selectedIcon else unselectedIcon,
                        contentDescription = label,
                        tint = if (selectedTab == index) KodyarAccent else KodyarTertiary,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTab == index) KodyarAccent else KodyarTertiary
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color(0xFFFEF2F2)
                )
            )
        }
    }
}

// ======================== TAB 0: HOME SCREEN ========================
@Composable
fun HomeTabScreen(viewModel: KodyarViewModel) {
    val filteredErrorCodes by viewModel.filteredErrorCodes.collectAsState()
    val popularCodes = filteredErrorCodes.take(5)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp)
    ) {
        // Quick statistics and metrics dashboard card (High contrast)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MetricCounterItem(
                        count = "۵۰۰+",
                        label = "کد خطا",
                        icon = Icons.Default.Info,
                        color = KodyarAccent
                    )
                    VerticalDivider(modifier = Modifier.height(40.dp), color = KodyarSurfaceVariant)
                    MetricCounterItem(
                        count = "۲۰۰+",
                        label = "تکنسین",
                        icon = Icons.Default.Face,
                        color = KodyarPremium
                    )
                    VerticalDivider(modifier = Modifier.height(40.dp), color = KodyarSurfaceVariant)
                    MetricCounterItem(
                        count = "۱,۰۰۰+",
                        label = "حل شده",
                        icon = Icons.Default.CheckCircle,
                        color = KodyarSuccess
                    )
                }
            }
        }

        // Quick Category Shortcuts (High Contrast Navigation Cards)
        item {
            Column {
                Text(
                    text = "دسترسی سریع",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickCategoryCard(
                        title = "کدهای خطا",
                        subtitle = "عیب‌یابی سریع",
                        icon = Icons.Default.List,
                        accentColor = KodyarAccent,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.selectedTab.value = 1
                    }
                    QuickCategoryCard(
                        title = "اعزام تکنسین",
                        subtitle = "تعمیر حضوری",
                        icon = Icons.Default.Settings,
                        accentColor = KodyarPrimary,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.selectedTab.value = 2
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickCategoryCard(
                        title = "فروشگاه قطعات",
                        subtitle = "قطعات یدکی فابریک",
                        icon = Icons.Default.ShoppingCart,
                        accentColor = KodyarSuccess,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.selectedTab.value = 3
                    }
                    QuickCategoryCard(
                        title = "اشتراک ویژه",
                        subtitle = "دسترسی نامحدود",
                        icon = Icons.Default.Star,
                        accentColor = KodyarPremium,
                        modifier = Modifier.weight(1f)
                    ) {
                        viewModel.selectedTab.value = 4
                    }
                }
            }
        }

        // Popular/Frequent Error Codes Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "پرتکرارترین خطاهای اخیر",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                TextButton(onClick = { viewModel.selectedTab.value = 1 }) {
                    Text(
                        text = "مشاهده همه",
                        color = KodyarAccent,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        // Error code list
        if (popularCodes.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "کد خطایی یافت نشد. فیلترها را بررسی کنید.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextDarkSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        } else {
            items(popularCodes) { error ->
                ErrorCodeCard(errorCode = error) {
                    viewModel.selectedErrorCode.value = error
                }
            }
        }
    }
}

@Composable
fun MetricCounterItem(count: String, label: String, imageVector: androidx.compose.ui.graphics.vector.ImageVector? = null, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color.copy(alpha = 0.9f),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
        }
        Text(
            text = count,
            style = MaterialTheme.typography.titleLarge.copy(
                color = color,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextDarkSecondary,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}

@Composable
fun QuickCategoryCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier = Modifier.modifier?,
    modifier1: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier1
            .height(100.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextDarkSecondary,
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun QuickCategoryCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextDarkSecondary,
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ======================== TAB 1: ERROR CODES SCREEN ========================
@Composable
fun ErrorCodesTabScreen(viewModel: KodyarViewModel) {
    val filteredErrorCodes by viewModel.filteredErrorCodes.collectAsState()
    val selectedBrand by viewModel.selectedBrandFilter.collectAsState()
    val selectedDevice by viewModel.selectedDeviceFilter.collectAsState()

    val brands = listOf("همه", "سامسونگ", "ال جی", "بوش", "بوتان", "اسنوا")
    val devices = listOf("همه", "یخچال فریزر", "ماشین لباسشویی", "ماشین ظرفشویی", "پکیج دیواری")

    Column(modifier = Modifier.fillMaxSize()) {
        // Filters section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(vertical = 12.dp)
        ) {
            // Brand filters row
            Text(
                text = "انتخاب برند:",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextDarkSecondary,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(horizontal = 16.dp, bottom = 6.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(brands) { brand ->
                    val isSelected = selectedBrand == brand
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectBrand(brand) },
                        label = {
                            Text(
                                text = brand,
                                color = if (isSelected) Color.White else TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = KodyarAccent,
                            containerColor = KodyarBackground
                        ),
                        border = null
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Device type filters row
            Text(
                text = "نوع دستگاه:",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextDarkSecondary,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(horizontal = 16.dp, bottom = 6.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(devices) { device ->
                    val isSelected = selectedDevice == device
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectDevice(device) },
                        label = {
                            Text(
                                text = device,
                                color = if (isSelected) Color.White else TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = KodyarPrimary,
                            containerColor = KodyarBackground
                        ),
                        border = null
                    )
                }
            }
        }

        // Active filter status
        if (selectedBrand != "همه" || selectedDevice != "همه") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "فیلترها: $selectedBrand | $selectedDevice",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = KodyarPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "حذف فیلترها",
                    color = KodyarAccent,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.clickable { viewModel.clearFilters() }
                )
            }
        }

        // Error Codes list with perfect text contrast
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
        ) {
            if (filteredErrorCodes.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "یافت نشد",
                            tint = KodyarTertiary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "متاسفانه هیچ کد خطایی یافت نشد.",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "لطفاً عبارت دیگری را جستجو کنید یا فیلترها را تغییر دهید.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextDarkSecondary,
                                fontWeight = FontWeight.Medium
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(filteredErrorCodes) { errorCode ->
                    ErrorCodeCard(errorCode = errorCode) {
                        viewModel.selectedErrorCode.value = errorCode
                    }
                }
            }
        }
    }
}

@Composable
fun ErrorCodeCard(errorCode: ErrorCode, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // High contrast badge with dark texts for codes
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(KodyarAccent.copy(alpha = 0.12f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = errorCode.code,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = KodyarAccent,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${errorCode.brand} • ${errorCode.deviceType}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextDarkPrimary, // Stronger high contrast dark text
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                // Severity label with solid colors
                val (severityColor, severityText) = when (errorCode.severity) {
                    "High" -> Pair(KodyarAccent, "نیاز به تعمیر فوری")
                    "Medium" -> Pair(KodyarWarning, "احتمال خرابی متوسط")
                    else -> Pair(KodyarSuccess, "بررسی توسط کاربر")
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(severityColor.copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = severityText,
                        color = severityColor,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main error title (High contrast)
            Text(
                text = errorCode.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextDarkPrimary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Brief description (Solid slate gray for legibility)
            Text(
                text = errorCode.description,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextDarkSecondary,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "مشاهده نحوه رفع خطا",
                    color = KodyarPrimary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = KodyarPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ======================== TAB 2: TECHNICIANS SCREEN ========================
@Composable
fun TechniciansTabScreen(viewModel: KodyarViewModel) {
    val technicians = viewModel.technicians

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "تکنسین‌های متخصص کدیار۲۴",
            style = MaterialTheme.typography.titleLarge.copy(
                color = TextDarkPrimary,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
        )
        Text(
            text = "اعزام سریع مجرب‌ترین کادر فنی با گارانتی تعمیرات",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextDarkSecondary,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(technicians) { tech ->
                TechnicianCard(tech = tech) {
                    viewModel.requestTechnicianDispatch(tech)
                }
            }
        }
    }
}

@Composable
fun TechnicianCard(tech: Technician, onDispatchClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Profile placeholder
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(KodyarPrimary.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = KodyarPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = tech.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = tech.specialty,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = KodyarPremium,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                // Rating Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFEF9E7))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "امتیاز",
                        tint = Color(0xFFF1C40F),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = tech.rating.toString(),
                        color = Color(0xFF7F6000),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = KodyarSurfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // Details info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "سابقه کار:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDarkSecondary, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        text = "${tech.experienceYears} سال",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextDarkPrimary, fontWeight = FontWeight.Bold)
                    )
                }
                Column {
                    Text(
                        text = "محدوده پوشش:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDarkSecondary, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        text = tech.location,
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextDarkPrimary, fontWeight = FontWeight.Bold)
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "وضعیت حضور:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDarkSecondary, fontWeight = FontWeight.Medium)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(KodyarSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "آماده اعزام",
                            style = MaterialTheme.typography.bodyMedium.copy(color = KodyarSuccess, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action request button
            Button(
                onClick = onDispatchClick,
                colors = ButtonDefaults.buttonColors(containerColor = KodyarAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "درخواست اعزام تکنسین",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

// ======================== TAB 3: STORE SCREEN ========================
@Composable
fun StoreTabScreen(viewModel: KodyarViewModel) {
    val parts = viewModel.parts
    val cartItems by viewModel.cartItems.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "فروشگاه لوازم یدکی کدیار۲۴",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = TextDarkPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
            if (cartItems.isNotEmpty()) {
                Text(
                    text = "${cartItems.size} کالا در سبد",
                    color = KodyarAccent,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Text(
            text = "فروش قطعات اصلی تمام برندها با فاکتور رسمی شرکت",
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextDarkSecondary,
                fontWeight = FontWeight.Medium
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(parts) { part ->
                val isInCart = cartItems.contains(part.id)
                PartCard(
                    part = part,
                    isInCart = isInCart,
                    onCartToggle = { viewModel.toggleCartItem(part.id) }
                )
            }
        }
    }
}

@Composable
fun PartCard(part: AppliancePart, isInCart: Boolean, onCartToggle: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(KodyarPrimary.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = part.category,
                        color = KodyarPrimary,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Brand Tag
                Text(
                    text = "برند: ${part.brand}",
                    color = TextDarkSecondary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Part Name (High contrast)
            Text(
                text = part.name,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextDarkPrimary,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = KodyarSurfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "قیمت مصرف‌کننده:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDarkSecondary, fontWeight = FontWeight.Medium)
                    )
                    Text(
                        text = part.price,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = KodyarAccent,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                if (part.isAvailable) {
                    Button(
                        onClick = onCartToggle,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isInCart) KodyarSuccess else KodyarPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = if (isInCart) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isInCart) "موجود در سبد" else "افزودن به سبد",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(KodyarSurfaceVariant)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "ناموجود در انبار",
                            color = TextDarkSecondary,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

// ======================== TAB 4: ACCOUNT / SETTINGS SCREEN ========================
@Composable
fun AccountTabScreen(viewModel: KodyarViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "پروفایل و اشتراک من",
            style = MaterialTheme.typography.titleLarge.copy(
                color = TextDarkPrimary,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(top = 16.dp, bottom = 16.dp)
        )

        // Profile Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(KodyarAccent.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ک",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = KodyarAccent
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "کاربر گرامی کدیار۲۴",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextDarkPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "شماره همراه: ۰۹۱۲۳۴۵۶۷۸۹",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextDarkSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = KodyarSurfaceVariant)
                Spacer(modifier = Modifier.height(14.dp))

                // Premium badge
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(KodyarPremium.copy(alpha = 0.08f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "طلایی",
                            tint = KodyarPremium,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "اشتراک کدیار VIP",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = KodyarPremium,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "اعتبار تا پایان سال ۱۴۰۵",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDarkSecondary)
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(KodyarPremium)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "فعال",
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Actions List
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                AccountActionRow(
                    title = "تاریخچه درخواست‌های اعزام",
                    icon = Icons.Default.Settings,
                    trailing = "۲ مورد"
                )
                HorizontalDivider(color = KodyarSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                AccountActionRow(
                    title = "کیف پول الکترونیکی",
                    icon = Icons.Default.Add,
                    trailing = "۱۵۰,۰۰۰ تومان"
                )
                HorizontalDivider(color = KodyarSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                AccountActionRow(
                    title = "قوانین و ضمانت تعمیر کدیار۲۴",
                    icon = Icons.Default.Info,
                    trailing = ""
                )
                HorizontalDivider(color = KodyarSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
                AccountActionRow(
                    title = "ارتباط با پشتیبانی تلفنی",
                    icon = Icons.Default.Call,
                    trailing = "۲۴ ساعته"
                )
            }
        }
    }
}

@Composable
fun AccountActionRow(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, trailing: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = KodyarPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextDarkPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        if (trailing.isNotBlank()) {
            Text(
                text = trailing,
                color = KodyarAccent,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
            )
        } else {
            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = KodyarTertiary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

// ======================== OVERLAYS & DIALOGS ========================

@Composable
fun VoiceSearchDialog(viewModel: KodyarViewModel) {
    val statusText by viewModel.voiceSearchStatusText.collectAsState()
    val recognizedText by viewModel.speechRecognizedText.collectAsState()
    val isListening by viewModel.isSpeechRecognizerListening.collectAsState()

    // Listening pulsating wave animation
    val infiniteTransition = rememberInfiniteTransition()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, delayMillis = 100),
            repeatMode = RepeatMode.Reverse
        )
    )

    Dialog(onDismissRequest = { viewModel.stopVoiceSearch() }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(2.dp, KodyarAccent.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "جستجوی صوتی کدیار۲۴",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(18.dp))

                // Pulsing voice circle
                Box(
                    modifier = Modifier.size(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (isListening) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(scaleX = pulseScale, scaleY = pulseScale)
                                .clip(CircleShape)
                                .background(KodyarAccent.copy(alpha = 0.12f))
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(KodyarAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "ضبط صدا",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // High contrast status title
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = KodyarPrimary,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = TextAlign.Center
                )

                if (recognizedText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(KodyarBackground)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "گفته شما: \"$recognizedText\"",
                            color = KodyarAccent,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { viewModel.stopVoiceSearch() },
                    colors = ButtonDefaults.buttonColors(containerColor = KodyarPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "بستن",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color.White)
                    )
                }
            }
        }
    }
}

@Composable
fun ErrorCodeDetailDialog(errorCode: ErrorCode, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(KodyarAccent.copy(alpha = 0.12f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = errorCode.code,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = KodyarAccent,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Text(
                        text = "${errorCode.brand} • ${errorCode.deviceType}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextDarkPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = KodyarSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                // Title
                Text(
                    text = errorCode.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Description
                Text(
                    text = errorCode.description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextDarkSecondary,
                        fontWeight = FontWeight.Medium
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Solution Card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = KodyarAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "راهنمای حل قدم به قدم خطا:",
                                color = KodyarAccent,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorCode.solution,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextDarkPrimary,
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = KodyarPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "بستن راهنما", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DispatchSuccessDialog(technician: Technician, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(KodyarSuccess.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "موفق",
                        tint = KodyarSuccess,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "درخواست اعزام ثبت شد!",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = KodyarSuccess,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "هماهنگی نهایی با تکنسین ${technician.name} با موفقیت انجام شد. تکنسین مربوطه تا حداکثر ۳۰ دقیقه دیگر جهت هماهنگی ساعت حضور با شماره شما تماس خواهد گرفت.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextDarkPrimary,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = KodyarPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "متوجه شدم", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
