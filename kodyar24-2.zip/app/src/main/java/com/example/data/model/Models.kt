package com.example.data.model

data class ErrorCode(
    val id: String,
    val code: String,
    val brand: String,
    val deviceType: String,
    val title: String,
    val description: String,
    val solution: String,
    val severity: String // "High", "Medium", "Low"
)

data class Technician(
    val id: String,
    val name: String,
    val specialty: String,
    val rating: Float,
    val experienceYears: Int,
    val location: String,
    val phoneNumber: String,
    val isAvailable: Boolean = true
)

data class AppliancePart(
    val id: String,
    val name: String,
    val category: String,
    val price: String,
    val isAvailable: Boolean,
    val brand: String,
    val rating: Float
)

object KodyarData {
    val errorCodes = listOf(
        // Samsung
        ErrorCode(
            id = "err_1",
            code = "E1",
            brand = "سامسونگ",
            deviceType = "ماشین لباسشویی",
            title = "خطای تامین آب (Water Supply Error)",
            description = "آب به میزان کافی یا در زمان مناسب وارد مخزن ماشین لباسشویی نمی‌شود.",
            solution = "۱. شیر آب ورودی را چک کنید که کاملاً باز باشد.\n۲. شیلنگ ورودی آب را از نظر تاخوردگی یا مسدود شدن بررسی نمایید.\n۳. فیلتر توری شیر برقی ورودی را تمیز کنید.",
            severity = "Medium"
        ),
        ErrorCode(
            id = "err_2",
            code = "dE",
            brand = "سامسونگ",
            deviceType = "ماشین لباسشویی",
            title = "خطای قفل درب (Door Error)",
            description = "درب دستگاه به درستی بسته نشده یا میکروسوئیچ درب خراب است.",
            solution = "۱. بررسی کنید که لباس‌ها مانع بسته شدن درب نباشند.\n۲. درب را با فشار ملایم ببندید.\n۳. در صورت تکرار، میکروسوئیچ یا قفل الکترونیکی درب باید تعویض شود.",
            severity = "High"
        ),
        ErrorCode(
            id = "err_3",
            code = "5E",
            brand = "سامسونگ",
            deviceType = "ماشین لباسشویی",
            title = "خطای عدم تخلیه آب (Drain Error)",
            description = "آب درون ماشین لباسشویی پس از اتمام شستشو تخلیه نمی‌شود.",
            solution = "۱. فیلتر پمپ تخلیه در پایین دستگاه را باز و تمیز کنید.\n۲. شیلنگ تخلیه را چک کنید که مسدود نشده یا بیش از حد بالا نباشد.\n۳. پمپ تخلیه را از نظر سلامت الکتریکی بررسی کنید.",
            severity = "High"
        ),
        // LG
        ErrorCode(
            id = "err_4",
            code = "OE",
            brand = "ال جی",
            deviceType = "ماشین لباسشویی",
            title = "خطای تخلیه آب (Drain Error)",
            description = "دستگاه قادر به تخلیه آب مخزن در زمان مقرر نیست.",
            solution = "۱. فیلتر پمپ تخلیه را بررسی و اجسام خارجی را خارج کنید.\n۲. شیلنگ تخلیه آب را از نظر گرفتگی بررسی کنید.\n۳. پمپ تخلیه را بررسی و در صورت نیاز تعویض کنید.",
            severity = "High"
        ),
        ErrorCode(
            id = "err_5",
            code = "IE",
            brand = "ال جی",
            deviceType = "ماشین لباسشویی",
            title = "خطای ورود آب (Inlet Error)",
            description = "آب وارد دستگاه نمی‌شود یا فشار آب بسیار ناچیز است.",
            solution = "۱. فشار آب ساختمان را بررسی کنید.\n۲. شیلنگ ورودی را چک کنید.\n۳. صافی یا فیلتر شیر برقی را تمیز کنید.",
            severity = "Medium"
        ),
        // Bosch
        ErrorCode(
            id = "err_6",
            code = "E15",
            brand = "بوش",
            deviceType = "ماشین ظرفشویی",
            title = "فعال شدن سنسور آبریزی (Leakage Error)",
            description = "سیستم آب‌بندی کف دستگاه نشت آب را تشخیص داده و پمپ ایمنی فعال شده است.",
            solution = "۱. دستگاه را کج کنید تا آب جمع‌شده در کف آن خارج شود.\n۲. اتصالات شیلنگ‌ها و جت‌پمپ را از نظر نشتی بررسی کنید.\n۳. سنسور شناور کف را بررسی کنید.",
            severity = "High"
        ),
        ErrorCode(
            id = "err_7",
            code = "E09",
            brand = "بوش",
            deviceType = "ماشین ظرفشویی",
            title = "خطای المنت گرمکن (Heating Element Error)",
            description = "آب درون ماشین ظرفشویی گرم نمی‌شود یا المنت سوخته است.",
            solution = "۱. المنت حرارتی داخل جت‌پمپ را با مولتی‌متر تست کنید.\n۲. سیم‌کشی‌های مربوط به المنت را بررسی کنید.\n۳. رله‌های روی برد اصلی را تست کنید.",
            severity = "High"
        ),
        // Butane (پکیج بوتان)
        ErrorCode(
            id = "err_8",
            code = "E01",
            brand = "بوتان",
            deviceType = "پکیج دیواری",
            title = "عدم تشکیل شعله (Ignition Failure)",
            description = "سیستم جرقه زن پکیج فعال می‌شود اما شعله تشکیل نشده یا حسگر شعله (یونیزاسیون) آن را تشخیص نمی‌دهد.",
            solution = "۱. از باز بودن شیر گاز ورودی پکیج اطمینان حاصل کنید.\n۲. دکمه ریست پکیج را فشار دهید.\n۳. الکترود جرقه زن و حسگر شعله را با سمباده نرم تمیز کنید.",
            severity = "High"
        ),
        ErrorCode(
            id = "err_9",
            code = "E02",
            brand = "بوتان",
            deviceType = "پکیج دیواری",
            title = "فعال شدن کلید حرارتی (Overheating)",
            description = "دمای مبدل حرارتی پکیج بیش از حد مجاز بالا رفته و کلید ایمنی مدار را قطع کرده است.",
            solution = "۱. فشار بار پکیج را چک کنید (باید بین ۱ تا ۱.۵ بار باشد).\n۲. شیرهای رفت و برگشت رادیاتورها را چک کنید که باز باشند.\n۳. پمپ سیرکولاتور دستگاه را از نظر روان بودن چرخش بررسی کنید.",
            severity = "High"
        ),
        ErrorCode(
            id = "err_10",
            code = "E04",
            brand = "بوتان",
            deviceType = "پکیج دیواری",
            title = "افت فشار آب مدار گرمایش (Low Water Pressure)",
            description = "میزان آب موجود در مدار گرمایش پکیج از حد مجاز (کمتر از ۰.۵ بار) کمتر شده است.",
            solution = "۱. شیر پرکن مشکی یا آبی رنگ کف پکیج را خلاف جهت عقربه‌های ساعت باز کنید تا فشار عقربه روی ۱.۵ بار برسد.\n۲. شیر پرکن را محکم ببندید.\n۳. رادیاتورها را از نظر نشتی بررسی کنید.",
            severity = "Medium"
        ),
        // Snowa
        ErrorCode(
            id = "err_11",
            code = "F1",
            brand = "اسنوا",
            deviceType = "یخچال فریزر",
            title = "خطای سنسور دمای فریزر (Freezer Sensor)",
            description = "سنسور سنجش دمای داخل محفظه فریزر قطع یا اتصال کوتاه شده است.",
            solution = "۱. سوکت اتصال سیم سنسور فریزر روی برد اصلی را بررسی کنید.\n۲. سنسور را با اهم‌متر اندازه‌گیری کنید (باید متناسب با دما مقاومت نشان دهد).\n۳. سنسور را تعویض کنید.",
            severity = "Medium"
        ),
        ErrorCode(
            id = "err_12",
            code = "F2",
            brand = "اسنوا",
            deviceType = "یخچال فریزر",
            title = "خطای سنسور اواپراتور (Evaporator Sensor)",
            description = "سنسور دیفراست (برفک‌زدایی) اواپراتور دچار خرابی شده است.",
            solution = "۱. سنسور دیفراست اواپراتور را بررسی و تعویض کنید.\n۲. المنت دیفراست و ترموفیوز را چک کنید.\n۳. از کارکرد صحیح رله دیفراست برد فرمان مطمئن شوید.",
            severity = "High"
        )
    )

    val technicians = listOf(
        Technician(
            id = "tech_1",
            name = "مهندس علیرضا رضایی",
            specialty = "متخصص پکیج دیواری و آبگرمکن",
            rating = 4.9f,
            experienceYears = 12,
            location = "شمال و مرکز تهران",
            phoneNumber = "09121112233"
        ),
        Technician(
            id = "tech_2",
            name = "مهندس حمید صابری",
            specialty = "متخصص یخچال، ساید‌بای‌ساید و فریزر",
            rating = 4.8f,
            experienceYears = 9,
            location = "غرب و جنوب تهران",
            phoneNumber = "09124445566"
        ),
        Technician(
            id = "tech_3",
            name = "مهندس امیرحسین کریمی",
            specialty = "متخصص ماشین لباسشویی و ظرفشویی",
            rating = 4.9f,
            experienceYears = 10,
            location = "شرق و مرکز تهران",
            phoneNumber = "09127778899"
        ),
        Technician(
            id = "tech_4",
            name = "مهندس رضا احمدی",
            specialty = "تکنسین عمومی لوازم خانگی و کولرگازی",
            rating = 4.7f,
            experienceYears = 6,
            location = "کرج و حومه",
            phoneNumber = "09192223344"
        )
    )

    val parts = listOf(
        AppliancePart(
            id = "part_1",
            name = "شیر برقی لباسشویی سامسونگ اصل",
            category = "قطعات لباسشویی",
            price = "۴۸۰,۰۰۰ تومان",
            isAvailable = true,
            brand = "سامسونگ",
            rating = 4.7f
        ),
        AppliancePart(
            id = "part_2",
            name = "ترموستات یخچال فریزر اسنوا",
            category = "قطعات یخچال",
            price = "۳۲۰,۰۰۰ تومان",
            isAvailable = true,
            brand = "اسنوا",
            rating = 4.5f
        ),
        AppliancePart(
            id = "part_3",
            name = "پمپ تخلیه ماشین لباسشویی ال جی مگنتی",
            category = "قطعات لباسشویی",
            price = "۶۵۰,۰۰۰ تومان",
            isAvailable = true,
            brand = "ال جی",
            rating = 4.9f
        ),
        AppliancePart(
            id = "part_4",
            name = "فلوسوئیچ پکیج دیواری بوتان",
            category = "قطعات پکیج",
            price = "۲۹۰,۰۰۰ تومان",
            isAvailable = true,
            brand = "بوتان",
            rating = 4.4f
        ),
        AppliancePart(
            id = "part_5",
            name = "میکروسوئیچ درب لباسشویی بوش",
            category = "قطعات لباسشویی",
            price = "۸۹۰,۰۰۰ تومان",
            isAvailable = false,
            brand = "بوش",
            rating = 4.8f
        )
    )
}
