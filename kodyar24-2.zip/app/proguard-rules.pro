# Add project specific ProGuard rules here.
# By default, the noise reduction is disable, you can introduce your own rules.
